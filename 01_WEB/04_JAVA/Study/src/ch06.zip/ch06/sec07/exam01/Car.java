package ch06.sec07.exam01;

public class Car {
    String model = "그랜저";
    String color = "검정";
    int speed = 350;
}
