package ch06.sec07.exam02;

public class Koean {

    String nation = "대한민국";
    String name;
    String ssn;

    public Koean( String n, String s) {
        name = n;
        ssn = s;
    }
}
