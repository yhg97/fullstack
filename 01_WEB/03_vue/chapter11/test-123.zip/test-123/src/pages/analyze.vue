<template>
  <div class="container">
    <div class="d-flex">
      <div class="p-2 " style="flex: 1; text-align: center; border: 1px solid;">거래 내역</div>
    </div>
  </div>
</template>

  <script>

  </script>
  
  <style scoped>
  </style>