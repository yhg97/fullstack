<template>
  <div class="">
  <div class="container align-items-center col-lg-8 pt-4 pt-lg-0 content" data-aos="fade-left" style="position: relative;">
    <!-- 헤더 -->

    <!-- 컨텐츠 -->
    <div class="d-flex justify-content-between"  style="height: 200px;"> 
      <div class="b" style="flex: 1; text-align: center; border: 1px solid;">
        총 자산dddddddddddddddddddddddddddd총 자산dddddddddddddddddddddddddddd
      </div>
      <div class="d" style="flex: 1; text-align: center; border: 1px solid;">
        예산vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv예산vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv예산vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv예산vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv예산vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv예산vvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
      </div>
    </div>

    <div class="c" style="text-align: center; border: 1px solid; margin-top: 1rem; height: 60%; word-break: break-all; overflow-wrap: break-word;">
      height=""height=""height=""height=""height=""height=""height=""height=""height=""height=""height=""height=""height=""height=""height=""height=""height=""height=""height=""height=""height=""height=""height=""height=""
      <!-- <Datepicker v-model="date" /> 캘린더 버튼 -->
    </div>
  </div>
</div>
</template>

<script setup>

</script>

<style scoped>

</style>
