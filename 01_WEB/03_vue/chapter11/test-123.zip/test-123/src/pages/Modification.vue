<template>
  <div class="d-flex justify-content-center">
    <div class="p-2"></div>
    <div class="p-2" data-aos="fade-left">
      <Playground />
    </div>
    <div class="p-2"></div>
  </div>
</template>

<script setup>
import Playground from '@/components/Playground.vue';
// import DateInfo from '@/components/DateInfo.vue';
</script>

<style scoped></style>
